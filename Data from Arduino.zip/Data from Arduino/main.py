# -*- coding: utf-8 -*-
import serial
from datetime import date, datetime
import re
from sqlalchemy import create_engine, text
from sqlalchemy.orm import  sessionmaker
engine = create_engine("postgresql+psycopg2://postgres:12345678@185.246.67.18:5432/hive_db")
db_session = sessionmaker(engine, expire_on_commit=False)


def func(x):
    return (re.findall(r'-[0-9.,]+|[0-9.,]+', x))

r = serial.Serial('com8', 9600)
f = open('test.txt', 'w')
while True:
    h = func(str(r.readline()))
    t = func(str(r.readline()))
    g = func(str(r.readline()))
    t1 = t[0]
    h1 = h[0]
    g1 = g[0]
    print('Temp: ', t1, 'H: ', h1, 'Gramms: ', g1)
    with db_session() as session:
        result = session.execute(
            text(
                f"INSERT INTO hive_db (time, date, humidity, temperature, weight)"
                f"VALUES ('{str(datetime.now().time())}',  '{str(date.today())}', {h1}, {t1}, {g1});"
            )
        )
        session.commit()
        print(result)



